# $Id$

package Oceano::Seabird;

use warnings;
use strict;
use Encode;

#exportation de l'espace de nommage
#pour un module non entierement objet
require Exporter;
our @ISA         = qw(Exporter);
our %EXPORT_TAGS = ( 'all' => [qw()] );
our @EXPORT_OK   = ( @{ $EXPORT_TAGS{'all'} } );
our @EXPORT      = qw(&roscop);

=head1 NAME

Oceano::Seabird - Perl extension to compute Seabird oceanographic parameters

=head1 VERSION

Version 0.01

=cut

our $VERSION = '0.01';

=head1 SYNOPSIS

Ce module contient des fonctions de calcul de temperature, pression,
conductivité... Les calculs sont fait à partir des coefficients de
calibration Seabird.

Les calculs sont fait en IPTS90. Pour utiliser la température IPTS68, la
convertir avec la formule suivante :

$T90 = $T68 / 1.00024;


Exemples d'utilisation :

    use Oceano::Seabird;
    
    my $sb = Seabird->new($con_file);
    
    $temp = $sb->temp($F);
    $pres = $sb->pres($F, $T);
    $cond = $sb->cond($F, $T, $P);
    $ox   = $sb->ox($V, $T, $P, $S);

=head1 EXPORT

roscop

=head1 FUNCTIONS

=head2 new

Seabird->new($con_file, $capteur);

Constructeur à partir d'un fichier de configuration
  $con_file : fichier de configuration Seabird (.con)
  $capteur : 1 ou 2

Exemple : my $sb = Seabird->new($con_file);

=cut

sub new {
  my ($class, $con_file, $capteur) = @_;
  my (%c_temp, %c_cond, %c_pres, %c_ox);
  $class = ref($class) || $class;
  my $this = {};
  bless($this, $class);
  
  # recherche des valeurs dans le fichier de configuration
  open(DATA_CON, $con_file) or die "Impossible d'ouvrir $con_file\n";
  while(<DATA_CON>) {
    chomp;
    # chomp ne marche pas correctement car le fichier .con est au format DOS
    # avec un CRLF (^M^J ou OD OA) a la fin de chaque ligne
    # on vire le CR si present en fin de ligne
    $_ =~ s/^(.+)\r$/$1/;
    SWITCH: {
      
      ## capteurs secondaires
      if (defined($capteur) && $capteur==2) {
        # capteur secondaire de temperature
        if ($. == 10) {
          ($c_temp{f0},$c_temp{a},$c_temp{b},$c_temp{c},$c_temp{d}) = split;
          last SWITCH;
        }
        if ($. == 113) {
          ($c_temp{f0},$c_temp{g},$c_temp{h},$c_temp{i},$c_temp{j}) = split;
          last SWITCH;
        }
        # capteur secondaire de conductivite
        if ($. == 7) {
          ($c_cond{m},$c_cond{a},$c_cond{b},$c_cond{c},
            $c_cond{d},$c_cond{CPcor}) = split;
          last SWITCH;
        }
        if ($. == 112) {
          ($c_cond{g},$c_cond{h},$c_cond{i},$c_cond{j},
            $c_cond{CTcor},$c_cond{CPcor}) = split;
          last SWITCH;
        }
        # capteur secondaire d'oxygene
        if ($. == 169) {
          ($c_ox{Soc},$c_ox{TCor},$c_ox{Voffset}) = split;
          last SWITCH;
        }
        if ($. == 170) {
          ($c_ox{PCor}) = split;
          last SWITCH;
        }
      }

      ## capteurs primaires
      else {
        # capteur primaire de temperature
        if ($. == 5) {
          ($c_temp{f0},$c_temp{a},$c_temp{b},$c_temp{c},$c_temp{d}) = split;
          last SWITCH;
        }
        if ($. == 111) {
          ($c_temp{f0},$c_temp{g},$c_temp{h},$c_temp{i},$c_temp{j}) = split;
          last SWITCH;
        }
        # capteur primaire de conductivite
        if ($. == 2) {
          ($c_cond{m},$c_cond{a},$c_cond{b},$c_cond{c},
            $c_cond{d},$c_cond{CPcor}) = split;
          last SWITCH;
        }
        if ($. == 110) {
          ($c_cond{g},$c_cond{h},$c_cond{i},$c_cond{j},
            $c_cond{CTcor},$c_cond{CPcor}) = split;
          last SWITCH;
        }
        # capteur primaire d'oxygene
        if ($. == 165) {
          ($c_ox{Soc},$c_ox{TCor},$c_ox{Voffset}) = split;
          last SWITCH;
        }
        if ($. == 166) {
          ($c_ox{PCor}) = split;
          last SWITCH;
        }
      }
      
      # capteur de pression
      if ($. == 12) {
        ($c_pres{T1},$c_pres{T2},$c_pres{T3},$c_pres{T4},
          $c_pres{T5}) = split;
        # T5 n'est pas dans le fichier .con
        $c_pres{T5} = 0.000000e+000 if !defined($c_pres{T5}); 
        last SWITCH;
      }
      if ($. == 13) {
        ($c_pres{C1},$c_pres{C2},$c_pres{C3},$c_pres{C4}) = split;
        last SWITCH;
      }
      if ($. == 14) {
        ($c_pres{D1},$c_pres{D2}) = split;
        last SWITCH;
      }
    }
  }
  close DATA_CON;
  
  # initialisation des coefficients
  $this->{CTEMP} = \%c_temp;
  $this->{CPRES} = \%c_pres;
  $this->{CCOND} = \%c_cond;
  $this->{COX}   = \%c_ox;

  return $this;
}

=head2 new_h

Seabird->new_h($coef1, $coef2...);

Constructeur à partir de tables de hachage des coefficients
  $coef : référence d'une table de hachage

Exemple :
  my %coefT = (
    'g'      =>  4.13773278e-003,
    'h'      =>  6.28255735e-004,
    'i'      =>  2.06477531e-005,
    'j'      =>  2.06792678e-006,
    'f0'     =>  1000.000,
  );
  
  my $sb = Seabird->new_h(\%coefT);

=cut

sub new_h {
  my $class = shift @_;
  $class = ref($class) || $class;
  my $this = {};
  bless($this, $class);
  
  # initialisation des coefficients
  foreach my $coef (@_) {
    my @coef = keys %$coef;

    # temperature
    my @coef1 = qw(g h i j f0);
    my @coef2 = qw(a b c d f0);
    if ( &is_inc(\@coef1, \@coef) || &is_inc(\@coef2, \@coef) ) {
      if (defined($this->{CTEMP})) {
        die ("CTEMP deja defini");
      }
      else {
        $this->{CTEMP} = $coef;
      }
    }

    # pression
    @coef1 = qw(C1 C2 C3 D1 D2 T1 T2 T3 T4 T5);
    if (&is_inc(\@coef1, \@coef)) {
      if (defined($this->{CPRES})) {
        die ("CPRES deja defini");
      }
      else {
        $this->{CPRES} = $coef;
      }
    }

    # conductivite
    @coef1 = qw(g h i j CTcor CPcor);
    @coef2 = qw(a b c d m CPcor);
    if ( &is_inc(\@coef1, \@coef) || &is_inc(\@coef2, \@coef) ) {
      if (defined($this->{CCOND})) {
        die ("CCOND deja defini");
      }
      else {
        $this->{CCOND} = $coef;
      }
    }

    # oxygene
    @coef1 = qw(Soc Voffset TCor PCor);
    if (&is_inc(\@coef1, \@coef)) {
      if (defined($this->{COX})) {
        die ("COX deja defini");
      }
      else {
        $this->{COX}   = $coef;
      }
    }
  }

  return $this;
}

=head1 FUNCTIONS

=head2 temp

$sb->temp($F);

Calcul de la température

ENTREE:  

F = fréquence   [Hz]

SORTIE:

T = température [degree C (IPTS-90)]

EXEMPLE:

$temp = $sb->temp(3769.251);

=cut

sub temp {
  my ($this, $mesu) = @_;

  # verification des parametres
  die ("CTEMP non defini") if !($this->{CTEMP});
  die ("\$mesu non defini") if !defined($mesu);
  
  # initialisation des constantes
  my ($T, $coef, $F) = (undef, $this->{CTEMP}, $mesu);
  my %hc = %$coef;  # dereferencement de la table de hachage

  # calcul de la temperature
  # coefficients g,h,i,j
  if ($hc{g}) {
    $T = 1 / ($hc{g} +
              $hc{h} * log($hc{f0} / $F) +
              $hc{i} * log($hc{f0} / $F)**2 +
              $hc{j} * log($hc{f0} / $F)**3) - 273.15;
  }
  # coefficients a,b,c,d
  elsif ($hc{a}) {
    $T = 1 / ($hc{a} +
              $hc{b} * log($hc{f0} / $F) +
              $hc{c} * log($hc{f0} / $F)**2 +
              $hc{d} * log($hc{f0} / $F)**3) - 273.15;
    $T /= 1.00024; # conversion en ITS-90
  }
  
  return $T;
}

=head2 pres

$sb->pres($F, $T);

Calcul de la pression

ENTREE:  

F = fréquence   [Hz]

T = température [degree C (IPTS-90)]

SORTIE:

P = pression    [db]

EXEMPLE:

$pres = $sb->pres(33409.468, 26.6428);

=cut

sub pres {
  my ($this, $mesu, $temp) = @_;

  # verification des parametres
  die ("CPRES non defini") if !($this->{CPRES});
  die ("\$mesu non defini") if !defined($mesu);
  die ("\$temp non defini") if !defined($temp);
  
  # initialisation des constantes
  my ($P, $coef, $F, $T) = (undef, $this->{CPRES}, $mesu, $temp);
  my %hc = %$coef;

  # calcul de la pression
  my $C  = $hc{C1} + $hc{C2} * $T + $hc{C3} * $T**2;
  my $D  = $hc{D1} + $hc{D2} * $T;
  my $T0 = $hc{T1} + $hc{T2} * $T + $hc{T3} * $T**2 + 
           $hc{T4} * $T**3 + $hc{T5} * $T**4;

  $P = $C * (1 - $T0**2 / (1 / $F)**2) * 
       (1 - $D * (1 - $T0**2 / (1 / $F)**2));
  
  return $P;
}

=head2 cond

$sb->cond($F, $T, $P);

Calcul de la conductivité

ENTREE:  

F = fréquence   [Hz]

T = température [degree C (IPTS-90)]

P = pression    [db]

SORTIE:

C = conductivité  [Siemens/meters]

EXEMPLE:

$cond = $sb->cond(10613.864, 26.6428, 30.000);

=cut

sub cond {
  my ($this, $mesu, $temp, $pres) = @_;
  
  # verification des parametres
  die ("CCOND non defini") if !($this->{CCOND});
  die ("\$mesu non defini") if !defined($mesu);
  die ("\$temp non defini") if !defined($temp);
  die ("\$pres non defini") if !defined($pres);

  # initialisation des constantes
  my ($C, $coef, $F, $T, $P) = (undef, $this->{CCOND}, $mesu, $temp, $pres);
  my %hc = %$coef;
  
  # conversion frequence en kHz
  $F /= 1000;
  
  # calcul de la conductivite
  # coefficients g,h,i,j
  if ($hc{g}) {
    $C = ($hc{g} +
          $hc{h} * ($F**2) +
          $hc{i} * ($F**3) +
          $hc{j} * ($F**4)
         ) / (10 * (1 + $hc{CTcor} * $T + $hc{CPcor} * $P));
  }
  # coefficients a,b,c,d
  elsif ($hc{a}) {
    $C = ($hc{a} * ($F**$hc{m}) +
          $hc{b} * ($F**2) +
          $hc{c} +
          $hc{d} * $T
         ) / (10 * (1 + $hc{CPcor} * $P));
  }
  
  return $C;
}

=head2 ox

$sb->ox($V, $T, $P, $S);

Calcul de l'oxygène

ENTREE:  

V = tension     [volts]

T = température [degree C (IPTS-90)]

P = pression    [db]

S = salinité    [psu      (PSS-78)]

SORTIE:

O = oxygène     [ml/l]

EXEMPLE:

$ox = $sb->ox(3.0172, 26.6428, 30.000, 35.1166);

=cut

sub ox {
  my ($this, $mesu, $temp, $pres, $sal) = @_;

  # verification des parametres
  die ("COX non defini") if !($this->{COX});
  die ("\$mesu non defini") if !defined($mesu);
  die ("\$temp non defini") if !defined($temp);
  die ("\$pres non defini") if !defined($pres);
  die ("\$sal non defini") if !defined($sal);

  # initialisation des constantes
  my ($O, $coef, $V, $T, $P, $S) = (undef, $this->{COX}, $mesu, $temp, $pres,
                                    $sal);
  my %hc = %$coef;
  
  # calcul de l'oxygene
  $O = ($hc{Soc} * ($V + $hc{Voffset})) *
       exp($hc{TCor} * $T) *
       &oxsat($T,$S) *
       exp($hc{PCor} * $P);

  return $O;
}

# -----------------------
# fonctions privees
# -----------------------

# saturation en oxygene
sub oxsat {
  my ($T, $S) = @_;
 
  my $A1 = -173.4292;
  my $A2 =  249.6339;
  my $A3 =  143.3483;
  my $A4 = -21.8492;
  my $B1 = -0.033096;
  my $B2 =  0.014259;
  my $B3 = -0.00170;
  my $Ta =  273.15;
  
  return exp ( ( $A1 + $A2 * (100/$Ta) + 
                 $A3 * log($Ta/100) + $A4 * ($Ta/100) ) + 
               $S * ( $B1 + $B2 * ($Ta/100) + $B3 * ($Ta/100)**2 ) );
}

# inclusion d'un tableau dans un autre
sub is_inc {
  my ($tab1, $tab2) = @_;
  my %is_inc = ();
  foreach my $val1 (@$tab1) {
    foreach my $val2 (@$tab2) {
      if ($val1 eq $val2) {
        $is_inc{$val1} = 1;
        last;
      }
      else {
        $is_inc{$val1} = 0;
      }
    }
  }
  foreach (@$tab1) {
    return 0 if !($is_inc{$_});
  }
  return 1;
}

# -----------------------
# fonctions publiques supplementaires
# -----------------------

=head2 roscop

&roscop($param, $princ);

Conversion des paramètres Seabird en codes ROSCOP
  $param : paramètre Seabird
  $princ : capteur principal (booléen)
  
Exemples : 
  my $code_roscop = &roscop("t090C");
  my $code_roscop = &roscop("sal00", 1);

=cut

sub roscop {
  my ($param, $princ) = @_;
  my %roscop = (
    # Seabird     => ROSCOP[principal, capteur]
    # temperature (degres C)
    "T090C"       => ["TEMP", "TE01"],
    "T190C"       => ["TEMP", "TE02"],
    "T3890C"      => ["TEMP", "TEMP"],
    "T38_90C"     => ["TEMP", "TEMP"],
    "TV290C"      => ["TEMP", "TEMP"],
    "T4990C"      => ["TEMP", "TEMP"],
    "TNC90C"      => ["TEMP", "TEMP"],
    # salinite (PSU)
    "SAL00"       => ["PSAL", "PSA1"],
    "SAL11"       => ["PSAL", "PSA2"],
    "SAL01"       => ["PSAL", "PSAL"],
    "SAL10"       => ["PSAL", "PSAL"],
    "SAL"         => ["PSAL", "PSAL"],
    "SAL_"        => ["PSAL", "PSAL"],
    # conductivite (mho/m)
    "C0S/M"       => ["CNDC", "CND1"],
    "C1S/M"       => ["CNDC", "CND2"],
    "C_S/M"       => ["CNDC", "CNDC"],
    # oxygene (ml/l)
    "OXML/L"      => ["DOX1", "DO11"],
    "OXSML/L"     => ["DOX1", "DO21"],
    "SBEOX0ML/L"  => ["DOX1", "DO11"],
    "SBEOX1ML/L"  => ["DOX1", "DO21"],
    # oxygene (micromole/kg)
    "OXMM/KG"     => ["DOX2", "DO12"],
    "OXSMM/KG"    => ["DOX2", "DO22"],
    "SBEOX0MM/KG" => ["DOX2", "DO12"],
    "SBEOX1MM/KG" => ["DOX2", "DO22"],
  );
  
  return $roscop{ uc $param }[ ($princ) ? 0 : 1 ];
}


=head1 AUTHOR

Jacques Grelet, C<< <jacques.grelet at ird.fr> >>

Nolwenn Rannou

=head1 SUPPORT

You can find documentation for this module with the perldoc command.

    perldoc Oceano::Seabird

=head1 ACKNOWLEDGEMENTS

=head1 COPYRIGHT & LICENSE

Copyright 2007 Jacques Grelet, all rights reserved.

This program is free software; you can redistribute it and/or modify it
under the same terms as Perl itself.

=cut

1;    # End of Oceano::Seabird
