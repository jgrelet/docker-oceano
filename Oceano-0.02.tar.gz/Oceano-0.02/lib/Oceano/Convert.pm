# $Id: Convert.pm 284 2007-06-05 09:58:22Z nrannou $

package Oceano::Convert;

use warnings;
use strict;
use Encode;
use Test::More;
#exportation de l'espace de nommage
#pour un module non entierement objet
require Exporter;
our @ISA         = qw(Exporter);
our %EXPORT_TAGS = ( 'all' => [qw()] );
our @EXPORT_OK   = ( @{ $EXPORT_TAGS{'all'} } );
our @EXPORT      = qw(&julian &is_bissex
  &date2julian &julian2date &dateInit &dateFormat
  &positionDeci &positionSexa &roscopFormat);

=head1 NAME

Oceano::Convert - Perl extension to convert dates or positions

=head1 VERSION

Version 0.02

=cut

our $VERSION = '0.02';

=head1 SYNOPSIS

Ce module contient des fonctions de conversion de dates en jours juliens et des fonctions de conversion de positions en degres decimaux et sexagesimaux.

Exemples d'utilisation :

    use Oceano::Convert;
    
    my $julien = date2julian(1999,2001,01,10,12,0,0);
    my ($an,$mois,$jour,$heure,$min,$sec) = julian2date(1999,740.5);

    my $date = &dateFormat("8/7/2006 13:22:30", "%d/%m/%y");

    my $pos = positionDeci(121,8.10,"N");
    my ($deg,$min,$hemi) = positionSexa(121.135,"latitude");

=head1 EXPORT

julian, is_bissex, 
date2julian, julian2date, dateInit, dateFormat,
positionDeci, positionSexa, roscopFormat

=cut

# declarations de variables globales

my %Jourjulien = (
  0 => [ 0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334 ],
  1 => [ 0, 31, 60, 91, 121, 152, 182, 213, 244, 274, 305, 335 ]
);
my %Joursmois = (
  0 => [ 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 ],
  1 => [ 31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 ],
);

my %sismer;

my $lang = "EN";
my $tzone = "GMT";
my %timezone = (
  'IDLW'   => ['-1200', 'International Date Line West'],
  'NT'     => ['-1100', 'Nome'],
  'HST'    => ['-1000', 'Hawaii Standard'],
  'CAT'    => ['-1000', 'Central Alaska'],
  'AHST'   => ['-1000', 'Alaska-Hawaii Standard'],
  'AKST'   => ['-0900', 'Alaska Standard'],
  'YST'    => ['-0900', 'Yukon Standard'],
  'HDT'    => ['-0900', 'Hawaii Daylight'],
  'AKDT'   => ['-0800', 'Alaska Daylight'],
  'YDT'    => ['-0800', 'Yukon Daylight'],
  'PST'    => ['-0800', 'Pacific Standard'],
  'PDT'    => ['-0700', 'Pacific Daylight'],
  'MST'    => ['-0700', 'Mountain Standard'],
  'MDT'    => ['-0600', 'Mountain Daylight'],
  'CST'    => ['-0600', 'Central Standard'],
  'CDT'    => ['-0500', 'Central Daylight'],
  'EST'    => ['-0500', 'Eastern Standard'],
  'ACT'    => ['-0500', 'Brazil, Acre'],
  'SAT'    => ['-0400', 'Chile'],
  'CLST'   => ['-0400', 'Chile Standard'],
  'BOT'    => ['-0400', 'Bolivia'],
  'EDT'    => ['-0400', 'Eastern Daylight'],
  'AST'    => ['-0400', 'Atlantic Standard'],
  'AMT'    => ['-0400', 'Brazil, Amazon'],
  'ACST'   => ['-0400', 'Brazil, Acre Daylight'],
 #'NST'    => ['-0330', 'Newfoundland Standard       nst=North Sumatra +0630'],
  'NFT'    => ['-0330', 'Newfoundland'],
  'CLDT'   => ['-0300', 'Chile Daylight'],
 #'GST'    => ['-0300', 'Greenland Standard          gst=Guam Standard +1000'],
 #'BST'    => ['-0300', 'Brazil Standard             bst=British Summer +0100'],
 #'BRST'   => ['-0300', 'Brazil Standard'],
  'BRT'    => ['-0300', 'Brazil Standard'],
  'AMST'   => ['-0300', 'Brazil, Amazon Daylight'],
  'ADT'    => ['-0300', 'Atlantic Daylight'],
  'ART'    => ['-0300', 'Argentina'],
  'UYT'    => ['-0300', 'Uruguay'],
  'NDT'    => ['-0230', 'Newfoundland Daylight'],
  'AT'     => ['-0200', 'Azores'],
  'BRST'   => ['-0200', 'Brazil Daylight (official time)'],
  'FNT'    => ['-0200', 'Brazil, Fernando de Noronha'],
  'WAT'    => ['-0100', 'West Africa'],
  'FNST'   => ['-0100', 'Brazil, Fernando de Noronha Daylight'],
  'GMT'    => ['+0000', 'Greenwich Mean'],
  'UT'     => ['+0000', 'Universal (Coordinated)'],
  'UTC'    => ['+0000', 'Universal (Coordinated)'],
  'WET'    => ['+0000', 'Western European'],
  'CET'    => ['+0100', 'Central European'],
  'FWT'    => ['+0100', 'French Winter'],
  'MET'    => ['+0100', 'Middle European'],
  'MEZ'    => ['+0100', 'Middle European'],
  'MEWT'   => ['+0100', 'Middle European Winter'],
  'SWT'    => ['+0100', 'Swedish Winter'],
  'BST'    => ['+0100', 'British Summer              bst=Brazil standard  -0300'],
  'GB'     => ['+0100', 'GMT with daylight savings'],
  'WEST'   => ['+0000', 'Western European Daylight'],
  'CEST'   => ['+0200', 'Central European Summer'],
  'EET'    => ['+0200', 'Eastern Europe, USSR Zone 1'],
  'FST'    => ['+0200', 'French Summer'],
  'MEST'   => ['+0200', 'Middle European Summer'],
  'MESZ'   => ['+0200', 'Middle European Summer'],
  'METDST' => ['+0200', 'An alias for MEST used by HP-UX'],
  'SAST'   => ['+0200', 'South African Standard'],
  'SST'    => ['+0200', 'Swedish Summer              sst=South Sumatra +0700'],
  'EEST'   => ['+0300', 'Eastern Europe Summer'],
  'BT'     => ['+0300', 'Baghdad, USSR Zone 2'],
  'MSK'    => ['+0300', 'Moscow'],
  'EAT'    => ['+0300', 'East Africa'],
  'IT'     => ['+0330', 'Iran'],
  'ZP4'    => ['+0400', 'USSR Zone 3'],
  'MSD'    => ['+0300', 'Moscow Daylight'],
  'ZP5'    => ['+0500', 'USSR Zone 4'],
  'IST'    => ['+0530', 'Indian Standard'],
  'ZP6'    => ['+0600', 'USSR Zone 5'],
  'NOVST'  => ['+0600', 'Novosibirsk time zone, Russia'],
  'NST'    => ['+0630', 'North Sumatra               nst=Newfoundland Std -0330'],
 #'SST'    => ['+0700', 'South Sumatra, USSR Zone 6  sst=Swedish Summer +0200'],
  'JAVT'   => ['+0700', 'Java'],
  'ICT'    => ['+0700', 'Indo China Time'],
  'CCT'    => ['+0800', 'China Coast, USSR Zone 7'],
  'AWST'   => ['+0800', 'Australian Western Standard'],
  'WST'    => ['+0800', 'West Australian Standard'],
  'PHT'    => ['+0800', 'Asia Manila'],
  'JST'    => ['+0900', 'Japan Standard, USSR Zone 8'],
  'ROK'    => ['+0900', 'Republic of Korea'],
  'ACST'   => ['+0930', 'Australian Central Standard'],
  'CAST'   => ['+0930', 'Central Australian Standard'],
  'AEST'   => ['+1000', 'Australian Eastern Standard'],
  'EAST'   => ['+1000', 'Eastern Australian Standard'],
  'GST'    => ['+1000', 'Guam Standard, USSR Zone 9  gst=Greenland Std -0300'],
  'CHST'   => ['+1000', 'Guam Standard, USSR Zone 9  gst=Greenland Std -0300'],
  'ACDT'   => ['+1030', 'Australian Central Daylight'],
  'CADT'   => ['+1030', 'Central Australian Daylight'],
  'AEDT'   => ['+1100', 'Australian Eastern Daylight'],
  'EADT'   => ['+1100', 'Eastern Australian Daylight'],
  'IDLE'   => ['+1200', 'International Date Line East'],
  'NZST'   => ['+1200', 'New Zealand Standard'],
  'NZT'    => ['+1200', 'New Zealand'],
  'NZDT'   => ['+1300', 'New Zealand Daylight'],
);

=head1 FUNCTIONS

=head2 julian

&julian($julien, $heure, $min, $sec);

Calcul le jour julien decimal � partir d'un jour julien et d'une heure.

Exemple : my $julien = &julian(400, 10, 45, 30);

=cut

sub julian {
  my ( $jj, $heure, $min, $sec ) = @_;
  my $dec = ( ( $heure * 3600 ) + ( $min * 60 ) + $sec ) / 86400;
  return ( $jj + $dec );
}

=head2 is_bissex

&is_bissex($annee);

Determine si une annee est bissextile

Exemple : &is_bissex(2007);

=cut

sub is_bissex {
  my ($annee) = @_;
  if ( $annee !~ /\d{4}/ ) {
    die "Mauvais parametre '$annee' : format annee YYYY\n";
  }

  return ( ( ( $annee % 4 == 0 ) && ( $annee % 100 != 0 ) )
      || ( $annee % 400 == 0 ) );
}

=head2 date2julian

&date2julian($anneeRef, $annee, $mois, $jour, $heure, $min, $sec);

Calcul le jour julien decimal � partir d'une date, d'une heure et d'une ann�e
de r�f�rence.
l'origine est le 1 janvier de cette annee et vaut 0

Exemple : my $julien = date2julian(1999, 2001, 01, 10, 12, 0, 0);


Si le mois, le jour, l'heure, les minutes ou les secondes ne sont pas
d�finis, ils valent 0 ou 1 par d�faut. Ainsi &date2julian(1999, 2001, 03)
�quivaut � &date2julian(1999, 2001, 03, 01, 00, 00, 00).

Si l'ann�e est donn�e sur deux chiffres, elle est interpr�t�e selon la r�gle
suivante : 
  si $annee >= 70   alors $annee = 19XX
  si $annee < 70    alors $annee = 20XX

&date2julian(99, 01) retourne donc le nombre de jours entre le 01/01/1999 et 
le 01/01/2001.

=cut

sub date2julian {
  my ( $anneeRef, $annee, $mois, $jour, $heure, $min, $sec ) = @_;
  my ( $julien, $julienDec, $julienAn );

  #controle du format des parametres
  $mois   = 1 if !defined($mois);
  $jour   = 1 if !defined($jour);
  $heure  = 0 if !defined($heure);
  $min    = 0 if !defined($min);
  $sec    = 0 if !defined($sec);
  $anneeRef += 1900 if ($anneeRef >= 70 && $anneeRef < 100);
  $anneeRef += 2000 if ($anneeRef >= 0 && $anneeRef < 70);
  $annee    += 1900 if ($annee >= 70 && $annee < 100);
  $annee    += 2000 if ($annee >= 0 && $annee < 70);
 
  if ( $anneeRef !~ /\d{4}/ ) {
    die "Mauvais parametre '$anneeRef' : format anneeRef YYYY ou YY\n";
  }
  if ( $annee !~ /\d{4}/ ) {
    die "Mauvais parametre '$annee' : format annee YYYY ou YY\n";
  }
  if ( $mois !~ /\d{1,2}/ || $mois < 1 || $mois > 12 ) {
    die "Mauvais parametre '$mois' : format mois MM\n";
  }
  if ( $jour !~ /\d{1,2}/ || $jour < 1 || $jour > 31 ) {
    die "Mauvais parametre '$jour' : format jour JJ\n";
  }
  if ( $heure !~ /\d{1,2}/ || $heure < 0 || $heure > 23 ) {
    die "Mauvais parametre '$heure' : format heure hh\n";
  }
  if ( $min !~ /\d{1,2}/ || $min < 0 || $min > 59 ) {
    die "Mauvais parametre '$min': format minutes mm\n";
  }
  if ( $sec !~ /\d{1,2}/ || $sec < 0 || $sec > 59 ) {
    die "Mauvais parametre '$sec' : format secondes ss\n";
  }

  # jours juliens de l'annee courante
  $julien
    = $Jourjulien{ &is_bissex($annee) ? 1 : 0 }[ $mois - 1 ] + $jour - 1;
  $julienDec = &julian( $julien, $heure, $min, $sec );

  # jours juliens des annees precedentes
  while ( $annee > $anneeRef ) {
    $annee--;

    # jours juliens de l'annee + 1 car origine = 0
    $julienAn = $Jourjulien{ &is_bissex($annee) ? 1 : 0 }[ 12 - 1 ] + 31 - 1;
    $julienDec += $julienAn + 1;
  }

  return $julienDec;
}

=head2 julian2date

&julian2date($anneeRef, $julien);

Calcul la date et l'heure � partir du jour julien decimal et d'une ann�e de
r�f�rence.
l'origine est le 1 janvier de cette annee et vaut 0

Exemple : my ($an,$mois,$jour,$heure,$min,$sec) = julian2date(1999, 740.5);

=cut

sub julian2date {
  my ( $anneeRef, $julienDec ) = @_;
  my ( $annee, $mois, $jour, $heure, $min, $sec );
  my ( $jj, $dec, $heureD, $minD, $secD );

  # controle du format des parametres
  $anneeRef += 1900 if ($anneeRef >= 70 && $anneeRef < 100);
  $anneeRef += 2000 if ($anneeRef >= 0 && $anneeRef < 70);

  if ( $anneeRef !~ /\d{4}/ ) {
    die "Mauvais parametre '$anneeRef' : format anneeRef YYYY ou YY\n";
  }

  # jour julien
  $jj  = int $julienDec;      #400
  $dec = $julienDec - $jj;    #.248

  # annee mois jour
  $annee = $anneeRef;
  my $cptjrs = 0;

  while ( $cptjrs < $jj ) {
    my $joursAn = &is_bissex($annee) ? 366 : 365;
    my $jourAn = $jj - $cptjrs + 1;

    # si on est pas dans la bonne annee
    # on passe a l'annee suivante
    if ( $jourAn > $joursAn ) {
      $annee++;
      $cptjrs += $joursAn;
      next;
    }

    # si on est dans la bonne annee
    # on cherche le mois et le jours
    for ( my $i = 0; $i < 12; $i++ ) {
      my $val = $Jourjulien{ &is_bissex($annee) ? 1 : 0 }[$i];
      my $valSuiv = $joursAn;
      $valSuiv = $Jourjulien{ &is_bissex($annee) ? 1 : 0 }[ $i + 1 ]
        if $i < 11;

      if ( $jourAn <= $valSuiv ) {    # on est dans la bonne case
        $mois = $i + 1;
        $jour = $jourAn - $val;
        $cptjrs += $jourAn;
        last;
      }
    }
  }

  # heures
  $heureD = ( $dec * 86400 ) / 3600;    #5.952
  $heure  = int $heureD;                #5
  $dec    = $heureD - $heure;           #.952
  # minutes
  $minD   = ( $dec * 3600 ) / 60;       #57.12
  $min    = int $minD;                  #57
  $dec    = $minD - $min;               #.12
  # secondes
  $secD   = $dec * 60;                  #7.2
  $sec    = int $secD;                  #7

  return ( $annee, $mois, $jour, $heure, $min, $sec );
}

=head2 dateInit

&dateInit($lang, $timezone);

Initialise la langue et la zone horaire utilisee par dateFormat
  $lang : EN ou FR
  $timezone : code de zone

Exemple : &dateInit("FR", "GMT");

Les codes de zones sont calques sur Date::Manip :

      IDLW    -1200    International Date Line West
      NT      -1100    Nome
      HST     -1000    Hawaii Standard
      CAT     -1000    Central Alaska
      AHST    -1000    Alaska-Hawaii Standard
      AKST    -0900    Alaska Standard
      YST     -0900    Yukon Standard
      HDT     -0900    Hawaii Daylight
      AKDT    -0800    Alaska Daylight
      YDT     -0800    Yukon Daylight
      PST     -0800    Pacific Standard
      PDT     -0700    Pacific Daylight
      MST     -0700    Mountain Standard
      MDT     -0600    Mountain Daylight
      CST     -0600    Central Standard
      CDT     -0500    Central Daylight
      EST     -0500    Eastern Standard
      ACT     -0500    Brazil, Acre
      SAT     -0400    Chile
      CLST    -0400    Chile Standard
      BOT     -0400    Bolivia
      EDT     -0400    Eastern Daylight
      AST     -0400    Atlantic Standard
      AMT     -0400    Brazil, Amazon
      ACST    -0400    Brazil, Acre Daylight
     #NST     -0330    Newfoundland Standard       nst=North Sumatra    +0630
      NFT     -0330    Newfoundland
      CLDT    -0300    Chile Daylight
     #GST     -0300    Greenland Standard          gst=Guam Standard    +1000
     #BST     -0300    Brazil Standard             bst=British Summer   +0100
     #BRST    -0300    Brazil Standard
      BRT     -0300    Brazil Standard
      AMST    -0300    Brazil, Amazon Daylight
      ADT     -0300    Atlantic Daylight
      ART     -0300    Argentina
      UYT     -0300    Uruguay
      NDT     -0230    Newfoundland Daylight
      AT      -0200    Azores
      BRST    -0200    Brazil Daylight (official time)
      FNT     -0200    Brazil, Fernando de Noronha
      WAT     -0100    West Africa
      FNST    -0100    Brazil, Fernando de Noronha Daylight
      GMT     +0000    Greenwich Mean
      UT      +0000    Universal (Coordinated)
      UTC     +0000    Universal (Coordinated)
      WET     +0000    Western European
      CET     +0100    Central European
      FWT     +0100    French Winter
      MET     +0100    Middle European
      MEZ     +0100    Middle European
      MEWT    +0100    Middle European Winter
      SWT     +0100    Swedish Winter
      BST     +0100    British Summer              bst=Brazil standard  -0300
      GB      +0100    GMT with daylight savings
      WEST    +0000    Western European Daylight
      CEST    +0200    Central European Summer
      EET     +0200    Eastern Europe, USSR Zone 1
      FST     +0200    French Summer
      MEST    +0200    Middle European Summer
      MESZ    +0200    Middle European Summer
      METDST  +0200    An alias for MEST used by HP-UX
      SAST    +0200    South African Standard
      SST     +0200    Swedish Summer              sst=South Sumatra    +0700
      EEST    +0300    Eastern Europe Summer
      BT      +0300    Baghdad, USSR Zone 2
      MSK     +0300    Moscow
      EAT     +0300    East Africa
      IT      +0330    Iran
      ZP4     +0400    USSR Zone 3
      MSD     +0300    Moscow Daylight
      ZP5     +0500    USSR Zone 4
      IST     +0530    Indian Standard
      ZP6     +0600    USSR Zone 5
      NOVST   +0600    Novosibirsk time zone, Russia
      NST     +0630    North Sumatra               nst=Newfoundland Std -0330
     #SST     +0700    South Sumatra, USSR Zone 6  sst=Swedish Summer   +0200
      JAVT    +0700    Java
      ICT     +0700    Indo China Time
      CCT     +0800    China Coast, USSR Zone 7
      AWST    +0800    Australian Western Standard
      WST     +0800    West Australian Standard
      PHT     +0800    Asia Manila
      JST     +0900    Japan Standard, USSR Zone 8
      ROK     +0900    Republic of Korea
      ACST    +0930    Australian Central Standard
      CAST    +0930    Central Australian Standard
      AEST    +1000    Australian Eastern Standard
      EAST    +1000    Eastern Australian Standard
      GST     +1000    Guam Standard, USSR Zone 9  gst=Greenland Std    -0300
      CHST    +1000    Guam Standard, USSR Zone 9  gst=Greenland Std    -0300
      ACDT    +1030    Australian Central Daylight
      CADT    +1030    Central Australian Daylight
      AEDT    +1100    Australian Eastern Daylight
      EADT    +1100    Eastern Australian Daylight
      IDLE    +1200    International Date Line East
      NZST    +1200    New Zealand Standard
      NZT     +1200    New Zealand
      NZDT    +1300    New Zealand Daylight
=cut

sub dateInit {
  $lang = "EN";
  $tzone = "GMT";
  
  $lang = $_[0] if ($_[0] && $_[0] =~ /(FR)|(EN)/i);
  foreach (keys %timezone) {
    $tzone = $_[1] if ($_[1] && $_[1] =~ /$_/i);
  }
}

=head2 dateFormat

&dateFormat($date, $format);

Changement du format d'affichage d'une date
  $date : date a formater selon la langue
    "NOW"
    MM/DD/YY HH:II:SS
    Mois DD YY HH:II:SS
    
    "MAINTENANT"
    DD/MM/YY HH:II:SS
    DD Mois YY HH:II:SS
    
    MM, DD, HH, II, SS correspondent aux mois, jours, heure, minutes, 
    secondes et peuvent etre des entiers sur 1 ou 2 chiffres.
    YY correspond a l'annee sur 2 ou 4 chiffres.
  
  $format : chaine de caracteres representant le nouveau format
    %Y      annee             0001 a 9999
    %y      annee             00 a 99

    %m      mois              01 a 12
    %B      nom du mois       janvier a decembre
    %b,%h   nom du mois       jan a dec

    %d      jour              01 a 31
    %j      jour de l'annee   001 a 366   

    %H      heure             00 a 23
    %M      minute            00 a 59
    %S      seconde           00 a 59

    %x      %d/%m/%Y          ou %m/%d/%Y selon la langue
    %R      %H:%M
    %T,%X   %H:%M:%S
    %q      %Y%m%d
    %q      %Y%m%d%H%M%S

Si $format n'est pas specifie, le format par defaut est %q.
Si $date n'est pas specifie ou vaut null, la date actuelle est choisie.

Exemples : 
  &dateInit("FR","GMT");

  # 20060728132230
  my $date = &dateFormat("28/7/06 13:22:30");
  
  # 08/07/06 
  my $date = &dateFormat("8/7/2006 13:22:30", "%d/%m/%y");

  # 28 juillet 2006, 13:22:00
  my $date = &dateFormat("28/07/06 13:22", "%d %M %Y, %h:%i:%s");

=cut

sub dateFormat {
  my ($DATE, $FORMAT) = @_;
  
  ($DATE, $FORMAT) = (undef, $DATE) if ($DATE && $DATE =~ /%/);
  $DATE = "now" if !$DATE;
  $FORMAT = "%q" if !$FORMAT;
  my ($Y,$m,$d,$H,$M,$S) = (0,0,0,0,0,0);
  my ($y,$B,$b,$j);
  my $i_mois;
  my @mois = (
    ['janvier',   'january',   'jan', 'jan'],
    ['fevrier',   'february',  'fev', 'feb'],
    ['mars',      'march',     'mar', 'mar'],
    ['avril',     'april',     'avr', 'apr'],
    ['mai',       'may',       'mai', 'may'],
    ['juin',      'june',      'jun', 'jun'],
    ['juillet',   'july',      'jul', 'jul'],
    ['aout',      'august',    'aou', 'aug'],
    ['septembre', 'september', 'sep', 'sep'],
    ['octobre',   'october',   'oct', 'oct'],
    ['novembre',  'november',  'nov', 'nov'],
    ['decembre',  'december',  'dec', 'dec'],
  );

  # date par defaut, date actuelle
  if ($DATE =~ /now/i || $DATE =~ /maintenant/i) {
    ($S,$M,$H,$d,$m,$Y) = localtime(time);
    $m += 1;    # les mois vont de 0 a 11
    $Y += 1900; # l'annee est le nombre d'annees depuis 1900
  }

  # recuperation de la date
  elsif ($DATE =~ /(\d+)[\/-](\d+)[\/-](\d+)/) { # 25/05/2007
    ($d,$m,$Y) = ($1,$2,$3) if ($lang eq "FR");
    ($m,$d,$Y) = ($1,$2,$3) if ($lang eq "EN");
  }
  elsif ($DATE =~ /(\d+)\s+([a-z]+)\s+(\d+)/i) { # 25 mai 2007    
    for ($i_mois=0; $i_mois<12; $i_mois++) {
      # si le mois est egal au mois francais
      if (($mois[$i_mois][0] eq lc $2) || ($mois[$i_mois][2] eq lc $2)) {
        ($d,$m,$Y) = ($1,$i_mois+1,$3);
      }
    }
  }
  elsif ($DATE =~ /([a-z]+)\s+(\d+)\s+(\d+)/i) { # May 25 2007
    for ($i_mois=0; $i_mois<12; $i_mois++) {
      # si le mois est egal au mois anglais
      if (($mois[$i_mois][1] eq lc $1) || ($mois[$i_mois][3] eq lc $1)) {
        ($m,$d,$Y) = ($i_mois+1,$2,$3);
      }
    }
  }
  else {
    die "Mauvais parametre '$DATE' dans &dateFormat(\$DATE, \$FORMAT)\n";
  }
  
  # recuperation de l'heure
  if ($DATE =~ m{(\d+):(\d+):(\d+)}) { # 20:11:31
    ($H,$M,$S) = ($1,$2,$3);
  }
  elsif ($DATE =~ m{(\d+):(\d+)}) { # 20:11
    ($H,$M) = ($1,$2);
  }

  # interpretation de la date
  $Y += 1900 if ($Y >= 70 && $Y < 100);
  $Y += 2000 if ($Y >= 0 && $Y < 70);
  
  # repercussions du timezone sur l'heure et la date
  my $tz  = substr($timezone{$tzone}[0], 0, 1); # signe
  my $tzh = substr($timezone{$tzone}[0], 1, 2); # heures
  my $tzm = substr($timezone{$tzone}[0], 3, 2); # minutes
  $H -= $tz.$tzh;
  $M -= $tz.$tzm;
  
  $H++ if ($M > 59); # heures
  $H-- if ($M < 0);
  $M = $M % 60;
  
  $d++ if ($H > 23); # jours
  $d-- if ($H < 0);
  $H = $H % 24;
  
  $m++ if ($d > $Joursmois{ &is_bissex($Y) ? 1 : 0 }[ $m - 1 ]); # mois
  $m-- if ($d < 1);
  $d = ($d - 1) % $Joursmois{ &is_bissex($Y) ? 1 : 0 }[ $m % 12 - 1] + 1;  

  $Y++ if ($m > 12); # annees
  $Y-- if ($m < 1);
  $m = ($m - 1) % 12 + 1; # mois 0..11 + 1
  
  # mise en forme des variables
  $y = substr($Y, 2, 4);
  $m = sprintf("%02s", $m);
  $B = $mois[$m-1][0]          if ($lang eq "FR");
  $B = ucfirst $mois[$m-1][1]  if ($lang eq "EN");
  $b = $mois[$m-1][2]          if ($lang eq "FR");
  $b = ucfirst $mois[$m-1][3]  if ($lang eq "EN");
  $d = sprintf("%02s", $d);
  $j = $Jourjulien{ &is_bissex($Y) ? 1 : 0 }[ $m-1 ] + $d;
  $j = sprintf("%03s", $j);
  $H = sprintf("%02s", $H);
  $M = sprintf("%02s", $M);
  $S = sprintf("%02s", $S);
  
  # formatage de la date retournee
  my $date = $FORMAT;
  
  $date =~ s/%Y/$Y/g;
  $date =~ s/%y/$y/g;
  $date =~ s/%m/$m/g;
  $date =~ s/%B/$B/g;
  $date =~ s/(%b)|(%h)/$b/g;
  $date =~ s/%d/$d/g;
  $date =~ s/%j/$j/g;
  $date =~ s/%H/$H/g;
  $date =~ s/%M/$M/g;
  $date =~ s/%S/$S/g;
  
  $date =~ s/%x/$d\/$m\/$Y/g if ($lang eq "FR");
  $date =~ s/%x/$m\/$d\/$Y/g if ($lang eq "EN");
  $date =~ s/%R/$H:$M/g;
  $date =~ s/(%T)|(%X)/$H:$M:$S/g;
  $date =~ s/%Q/$Y$m$d/g;
  $date =~ s/%q/$Y$m$d$H$M$S/g;
  
  return ( $date );
}

=head2 positionDeci

&positionDeci($deg, $min, $hemi);

Conversion degres sexagesimaux => degres decimaux
  $hemi : 'N', 'S', 'E' ou 'W'

Exemple : my $pos = positionDeci(121, 8.10, "N");

=cut

sub positionDeci {
  my ( $deg, $min, $hemi ) = @_;

  #controle du format des parametres
  $hemi = uc $hemi;
  if ( $hemi !~ /[NSEW]/ ) {
    die "Mauvais parametre '$hemi' : format hemi [NSEW]\n";
  }

  my $sign = 1;
  if ( $hemi eq "S" || $hemi eq "W" ) {
    $sign = -1;
  }
  my $tmp = $min;
  $min = abs $tmp;
  my $sec = ( $tmp - $min ) * 100;
  return ( ( $deg + ( $min + $sec / 100 ) / 60 ) * $sign );
}

=head2 positionSexa

&positionSexa($deg, $xy);

Conversion degres decimaux => degres sexagesimaux
  par exemple, positionSexa(121.135, "lat") retourne (121, 8.10, "N")
  $tmp : position decimale
  $xy : 'lat' (latitude) ou 'long' (longitude)

Exemple : my ($deg,$min,$hemi) = positionSexa(121.135, "latitude");

=cut

sub positionSexa {
  my ( $tmp, $xy ) = @_;
  my ( $deg, $min, $hemi );

  #controle du format des parametres
  $xy = uc $xy;
  if ( $xy !~ /LAT|LONG/ ) {
    die "Mauvais parametre '$xy' : format xy LAT|LONG\n";
  }

  # point cardinal
  if ( $xy eq "LAT" ) {
    $hemi = ( $tmp >= 0 ) ? "N" : "S";
  }
  elsif ( $xy eq "LONG" ) {
    $hemi = ( $tmp >= 0 ) ? "E" : "W";
  }

  # coordonnees
  $tmp = abs $tmp;
  $deg = int $tmp;
  $tmp = ( $tmp - $deg ) * 60;
  $min = $tmp;

  return ( $deg, $min, $hemi );
}

=head2 roscopFormat

&roscopFormat($code, $valeur, $sep);

Conversion d'une valeur en une chaine formatee selon un code ROSCOP
  $code : code ROSCOP
  $valeur : valeur a formater
  $sep : separateur

Exemple : my $str = roscopFormat("TEMP", 26.24, ";");

=cut

sub roscopFormat {
  my ( $code, $val, $sep ) = @_;
  my $res;
  
  # controle des parametres
  $sep = "" if !defined($sep);
  if ( $val !~ /[+-]?\d+(\.\d+)?([eE][+-]?\d+)?/ ) {
    die "Mauvais parametre '$val' : nombre reel attendu\n";
  }

  &read_physical_param_code;
  if ( !exists($sismer{"$code:1"}) ) {
    die "Mauvais parametre '$code' : code ROSCOP inconnu\n";
  }

  # formatage de la valeur
  if (($val == $sismer{"$code:6"}) || ($val == 1e36)) {
    $res = $sep."1e36"; # valeur par defaut
  }
  else {
    $res = sprintf($sep.$sismer{"$code:5"}, $val);
  }
  
  return $res;
}

#-------------------
# lecture du fichier de description des parametres physique (SISMER)
#-------------------
sub read_physical_param_code {
  my ( $c_physical_param_code,
    $l_label, $l_unit, $v_min, $v_max, $l_format, $v_default );
                                                                                
  # on lit maintenant le contenu du fichier roscop a la fin du script
  # apres la directive __data__
  while (<DATA>) {
    if (/^#/) {
      $. -= 1;
    }
    else {
      chomp;
      ( $c_physical_param_code,
        $l_label, $l_unit, $v_min, $v_max, $l_format, $v_default
      ) = split /;/;
      $sismer{"$c_physical_param_code:1"} = $l_label;
      $sismer{"$c_physical_param_code:2"} = $l_unit;
      $sismer{"$c_physical_param_code:3"} = $v_min;
      $sismer{"$c_physical_param_code:4"} = $v_max;
      $sismer{"$c_physical_param_code:5"} = $l_format;
      $sismer{"$c_physical_param_code:6"} = $v_default;
    }
  }
}

=head1 AUTHOR

Jacques Grelet, C<< <jacques.grelet at ird.fr> >>

Nolwenn Rannou

=head1 SUPPORT

You can find documentation for this module with the perldoc command.

    perldoc Oceano::Convert

=head1 ACKNOWLEDGEMENTS

=head1 COPYRIGHT & LICENSE

Copyright 2007 Jacques Grelet, all rights reserved.

This program is free software; you can redistribute it and/or modify it
under the same terms as Perl itself.

=cut

1;    # End of Oceano::Convert


__DATA__
# $Id: oceano2cdf.pl 260 2007-03-26 07:34:33Z jgrelet $
# code GF3 utilises au SISMER et fournit par M Fichaut
# 
#CODE;NAME;UNIT;MIN;MAX;FORMAT;DEFAULT
N/A;NOT AVAILABLE;N/A;;;%5.1g;1e36
CUPW;14C PRODUCTION UNKNOWN FILTER;milligram carbon/(m3.day);0;200;%6.2lf;999.99
C1UW;14C UPTAKE 0.2-1 MICRON;milligram carbon/(m3.day);0;100;%6.2lf;999.99
BFUP;19'BUTANOYLOXYFUCOXANTHINE;milligram/m3;0;5;%6.3lf;99.999
HFUP;19'HEXANOYLOXYFUCOXANTHINE;milligram/m3;0;5;%6.3lf;99.999
ASDW;ABSORPTION STANDARD DEVIATION;milligram/m3;0;10;%5.2lf;99.99
MALF;AL FLUX IN SETTLING PARTICLES;milligram/(m2.day);0;180;%6.2lf;999.99
ALKY;ALKALINITY;millimole/m3;1500;2500;%4.0lf;9999
ALKW;ALKALINITY;micromole/kg;0;9000;%6.1lf;9999.9
AXAP;ALLOXANTHINE;milligram/m3;0;5;%6.3lf;99.999
ABCP;ALPHA BETA CAROTENES;milligram/m3;0;5;%6.3lf;99.999
AMOW;AMMONIUM (NH4-N) CONTENT;micromole/kg;0;1;%6.3lf;99.999
AMON;AMMONIUM (NH4-N) CONTENT;millimole/m3;0;10;%6.2lf;999.99
NHRW;AMMONIUM REGENERATION;micromole nitrogen/(m3.day);0;99;%5.0lf;99999
NHUW;AMMONIUM UPTAKE;micromole nitrogen/(m3.day);0;900;%5.0lf;99999
ATMP;ATMOSPHERIC PRESSURE;hectopascal;1000;1030;%8.3lf;9999.999
ATMS;ATMOSPHERIC PRESSURE - SEA LEV;hectopascal;1000;1030;%8.3lf;9999.999
NFAW;AUTOTROPHIC NANOFLAGELLATES;10+3 cell/m3;0;900000;%6.0lf;999999
VTZA;AVER ZERO CROSSING WAVE PERIOD;second;0;500;%3.0lf;999
VAVH;AVER. HEIGHT HIGHEST 1/3 WAVE;metre;0;30;%5.2lf;99.99
NAVG;AVERAGED DATA CYCLE NUMBER;number;0;999;%3.0lf;999;0 10|0 50|0 100|0 200|0 500|0 1000
MALP;Al IN SUSPENDED MATTER;milligram/m3;0;99.999;%6.3lf;99.999
MALS;Al IN THE SEDIMENT;%;0;99;%6.3lf;99.999
BCCS;BACTERIA NUMBER SEDIMENT;10+9 cell/dm3;0;9999.9;%6.1lf;9999.9
BCMW;BACTERIAL BIOMASS IN SEA WATER;milligram C/m3;0;16;%6.3lf;99.999
BATH;BATHYMETRIC DEPTH;meter;0;11000;%6.1lf;-999.9
MBAP;Ba IN SUSPENDED MATTER;milligram/m3;0;99.9999;%7.4lf;99.9999
MBAS;Ba IN THE SEDIMENT;ppm;0;5000;%7.2lf;9999.99
MBRS;Br IN THE SEDIMENT;ppm;-50;50;%+6.2lf;-99.99
CO3P;CARBONATES CONTENT;%;0;99.99;%5.2lf;99.99
CODW;CHEMICAL OXYGEN DEMAND;millimole/m3;0;650;%7.3lf;999.999
CH1P;CHL-A(LESS DIVINYLCHL-A);milligram/m3;0;3;%6.3lf;99.999
CH2P;CHL-B(LESS DIVINYLCHL-B);milligram/m3;0;1;%6.3lf;99.999
CH1T;CHLOROPHYLL TOTAL;microgram/kg;0;10;%5.2lf;99.99
CPH1;CHLOROPHYLL-A TOTAL;milligram/m3;0;99;%5.2lf;99.99
CPHL;CHLOROPHYLL-A TOTAL;milligram/m3;0;99;%5.2lf;99.99
CPH2;CHLOROPHYLL-A TOTAL;milligram/m3;0;99;%5.2lf;99.99
CHAF;CHLOROPHYLL-A VERTICAL FLUX;milligram/(m2.day);0;99;%6.3lf;99.999
CPH3;CHLOROPHYLL-A/2 MICRON FILTER;milligram/m3;0;99;%5.2lf;99.99
CPH4;CHLOROPHYLL-A/20 MICRON FILTER;milligram/m3;0;99;%5.2lf;99.99
CHLB;CHLOROPHYLL-B TOTAL;milligram/m3;0;99;%5.2lf;99.99
CHLC;CHLOROPHYLL-C TOTAL;milligram/m3;0;99;%6.3lf;99.999
CHCZ;CHLOROPHYLL-C1+C2;milligram/m3;0;900;%6.3lf;99.999
CHC3;CHLOROPHYLL-C3;milligram/m3;0;5;%6.3lf;99.999
CHLT;CHLOROPHYLL-TOTAL;milligram/m3;0;99;%5.2lf;99.99
CLAY;CLAY IN THE SEDIMENT;%;0;100;%6.2lf;999.99
FCO2;CO2 FUGACITY;microatmosphere;0;1000;%6.1lf;9999.9
XCO2;CO2 MOLE FRACTION IN DRY GAS;ppm;0;5000;%8.3lf;9999.999
PCO2;CO2 PART. PRES IN DRY/WET GAS;microatmosphere;100;700;%7.3lf;999.999
COPF;COCCOLITHOPHORIDAE PPC FLUX;milligram C/(m2.day);0;99.999;%6.3lf;99.999
PREC;CORRECTED SEA PRESSURE;decibar=10000 pascals;0;6500;%6.1lf;-999.9
MCUF;CU FLUX IN SETTLING PARTICLES;microgram/(m2.day);0;120;%6.2lf;999.99
EWCS;CURRENT EAST  STD. DEVIATION;meter/second;0;20;%+6.3lf;99.999;0 5|0 10
EWCT;CURRENT EAST COMPONENT;meter/second;-100;100;%+7.3lf;-99.999;-10 10|-20 20|-50 50|-100 100|-150 150|-200 200
NSCT;CURRENT NORTH COMPONENT;meter/second;-100;100;%+7.3lf;-99.999;-10 10|-20 20|-50 50|-100 100|-150 150|-200 200
NSCS;CURRENT NORTH STD. DEVIATION;meter/second;0;20;%+7.3lf;-99.999;0 5|0 10
MCAP;Ca IN SUSPENDED MATTER;milligram/m3;0;99.999;%6.3lf;99.999
MCAS;Ca IN THE SEDIMENT;%;0;99;%6.3lf;99.999
MCES;Ce IN THE SEDIMENT;ppm;0;900;%6.2lf;999.99
MCLP;Cl IN SUSPENDED MATTER;milligram/m3;0;99.999;%6.3lf;99.999
MCRS;Cr IN THE SEDIMENT;ppm;0;900;%6.2lf;999.99
MCUS;Cu IN THE SEDIMENT;ppm;0;900;%6.2lf;999.99
DCAW;DARK CARBON ABSORPTION;milligram/m3;-0.05;10;%5.2lf;99.99
CDFW;DARK FIXATION;milligram carbon/(m3.day);0;2;%5.2lf;99.99
DATE;DATE;mmdd;101;1231;%4.4d;9999
DAYX;DAY WITHIN MONTH;dd;1;31;%2.2d;99
DAYD;DAY WITHIN YEAR;decimal day;1;366;%9.5lf;999.99999
D13C;DELTA 13 C SIGNATURE;%;-50;100;%6.2lf;999.99
C13D;DELTA 13C (13C/12C);per thousand;-50;100;%5.1lf;999.9
N15D;DELTA 15N (15N/14N);per thousand;-2;10;%5.1lf;999.9
HELD;DELTA HELIUM 3;%;-99;99;%6.2lf;999.99
DENS;DENSITY (Sigma-theta);kg/m3;10;35;%6.3lf;99.999;0 20|10 20|0 30|10 30|20 30
DEN1;DENSITY (Sigma-theta) PRIMARY SENSORS;kg/m3;10;35;%6.3lf;99.999;0 20|10 20|0 30|10 30|20 30
DEN2;DENSITY (Sigma-theta) SECONDARY SENSORS;kg/m3;10;35;%6.3lf;99.999;0 20|10 20|0 30|10 30|20 30
DPS1;DEPTH BELOW BOTTOM-LOWER LIMIT;meter;0;11000;%6.1lf;-999.9
DPSF;DEPTH BELOW SEA FLOOR;meter;0;11000;%6.1lf;-999.9
DEPH;DEPTH BELOW SEA SURFACE;meter;0;6000;%6.1lf;-999.9;0 50|0 100|0 250|0 500|0 700|0 800|0 900|0 1000|0 1200|0 1500|0 2000|0 2500|0 4000|1000 2000|3800 4200|2000 4000
DXAP;DIADINOXANTHINE;milligram/m3;0;5;%6.3lf;99.999
DIPF;DIATOMS PPC FLUX;milligram C/(m2.day);0;99.999;%6.3lf;99.999
TXAP;DIATOXANTHINE;milligram/m3;0;5;%6.3lf;99.999
DFPF;DINOFLAGELLATES PPC FLUX;milligram C/(m2.day);0;99.999;%6.3lf;99.999
HCDT;DIRECTION REL. TRUE NORTH;degree;0;360;%5.1lf;999.9
TPAW;DISS. TRIPHOSPHATE ADENOSINE;milligram/m3;0;1;%6.3lf;99.999
ETHW;DISSOLVED 234 TH ACT. ERROR;Bq/m3;0;90;%6.3lf;99.999
TH4W;DISSOLVED 234TH;Bq/m3;0;90;%6.3lf;99.999
CL4W;DISSOLVED C-TETRACHLORIDE;picomole/kg;0;10;%6.3lf;99.999
CO2W;DISSOLVED CARBON DIOXYD (CO2);millimole/m3;0;4800;%6.1lf;9999.9
CF1W;DISSOLVED CFC11;picomole/kg;-0.01;90;%7.4lf;99.9999
CE1W;DISSOLVED CFC11 ERROR;picomole/kg;0;0.5;%6.3lf;99.999
EF1W;DISSOLVED CFC11 ERROR;%;0;100;%6.3lf;99.999
CF3W;DISSOLVED CFC113;picomole/kg;0;5;%6.3lf;99.999
CE3W;DISSOLVED CFC113 ERROR;picomole/kg;0;0.5;%6.3lf;99.999
EF3W;DISSOLVED CFC113 ERROR;%;0;100;%6.3lf;99.999
CF2W;DISSOLVED CFC12;picomole/kg;-0.01;90;%7.4lf;99.9999
CE2W;DISSOLVED CFC12 ERROR;picomole/kg;0;0.5;%6.3lf;99.999
EF2W;DISSOLVED CFC12 ERROR;%;0;100;%6.3lf;99.999
HELW;DISSOLVED HELIUM;nanomole/kg;1;2;%7.4lf;99.9999
HEEW;DISSOLVED HELIUM ERROR;nanomole/kg;0;1;%7.4lf;99.9999
TINW;DISSOLVED INORGANIC NITROGEN;millimole/m3;0;100;%6.3lf;99.999
NEOW;DISSOLVED NEON;nanomole/kg;4;8;%7.4lf;99.9999
NEEW;DISSOLVED NEON ERROR;nanomole/kg;0;1;%7.4lf;99.9999
CORG;DISSOLVED ORGANIC CARBON;millimole/m3;0;1000;%5.0lf;99999
NODW;DISSOLVED ORGANIC NITROGEN;micromole/kg;0;99;%5.2lf;99.99
NORG;DISSOLVED ORGANIC NITROGEN;millimole/m3;0;50;%6.3lf;99.999
DOPW;DISSOLVED ORGANIC PHOSPHORUS;millimole/m3;0;50;%6.3lf;99.999
PODW;DISSOLVED ORGANIC PHOSPHORUS;micromole/kg;0;5;%5.2lf;99.99
DOX1;DISSOLVED OXYGEN;ml/l;0;10;%5.2lf;99.99;0 4|0 6|2 6|0 8|2 8
DOX2;DISSOLVED OXYGEN;micromole/kg;0;450;%7.3lf;999.999;0 100|0 200|100 300
DOXY;DISSOLVED OXYGEN;millimole/m3;0;650;%7.3lf;999.999;0 100|0 200|100 300
TRIW;DISSOLVED TRITIUM;TU;0;2;%6.3lf;99.999
TREW;DISSOLVED TRITIUM ERROR;TU;0;5;%6.3lf;99.999
CHAD;DIVINYL CHLOROPHYLL-A;milligram/m3;0;9;%6.3lf;99.999
CHBD;DIVINYL-CHLOROPHYLL-B;milligram/m3;0;5;%6.3lf;99.999
DRYT;DRY BULB TEMPERATURE;Celsius degree;0;90;%5.1lf;999.9
DRDD;DURATION (DAYS);ddd;0;999;%3.0lf;999
CNDC;ELECTRICAL CONDUCTIVITY;mho/meter;3;7;%5.3lf;9.999
ETDD;ELLAPSED TIME;decimal days;0;999;%9.5lf;999.99999
CHAE;EPIMERE CHLOROPHYLL-A;milligram/m3;0;5;%6.3lf;99.999
MFEF;FE FLUX IN SETTLING PARTICLES;milligram/(m2.day);0;100;%6.2lf;999.99
FLPF;FLAGELLATES PPC FLUX;milligram C/(m2.day);0;99.999;%6.3lf;99.999
FLU2;FLUORESCENCE;milligram/m3;0;1;%8.4lf;999.9999;0 1|0 5
FLUO;FLUORESCENCE;relative unit;-0.1;10;%6.3lf;99.999
FLU1;FLUORESCENCE;volt;-1;3;%6.3lf;99.999;|0 1|0 2|0 3|1 3
FUCP;FUCOXANTHINE;milligram/m3;0;5;%6.3lf;99.999
MFEP;Fe IN SUSPENDED MATTER;milligram/m3;0;99.999;%6.3lf;99.999
MFES;Fe IN THE SEDIMENT;%;0;99;%6.3lf;99.999
GLUC;GLUCIDE;milligram/m3;0;200;%5.0lf;99999
GSPD;GUST WIND SPEED;meter/second;0;99;%2.0lf;99
HEDW;HELIUM DEV. OF ISOTOPIC RATIO;%;-1.5;100;%8.4lf;999.9999
HEDE;HELIUM ISOTOPIC RATIO ERROR;%;0;100;%8.4lf;999.9999
NFHW;HETEROTROPHIC NANOFLAGELLATES;10+3 cell/m3;0;900000;%6.0lf;999999
HCSP;HORIZONTAL CURRENT SPEED;meter/second;0;9;%5.3lf;9.999
WSPD;HORIZONTAL WIND SPEED;meter/second;0;300;%6.2lf;999.99
HSUL;HYDROGEN SULPHIDE (H2S);millimole/m3;0;500;%6.2lf;999.99
MIIS;I IN THE SEDIMENT;ppm;0;900;%6.2lf;999.99
LGH5;IMMERGED/SURF IRRADIANCE RATIO;%;0;100;%6.2lf;999.99;0 10|0 50|0 75|25 50|25 75|25 100|50 75|50 100|75 100
RDIN;INCIDENT RADIATION;watt/m2;-500;500;%+5.1lf;-999.9;-100 100|-250 250|0 100|0 250
SPDI;INDICATED PLATFORM SPEED-SHIP;meter/second;0;90;%6.3lf;99.999
ISMP;INORGANIC SUSPENDED MATTER;gram/m3;0;10;%6.3lf;99.999
IODI;IODINE;millimole/m3;0;10;%5.2lf;99.99
OXIR;ISOTOPIC RATIO O18/O16;per thousand;-10;10;%6.2lf;999.99
MKKP;K IN SUSPENDED MATTER;milligram/m3;0;99.999;%6.3lf;99.999
MKKS;K IN THE SEDIMENT;%;0;99;%6.3lf;99.999
LATX;LATITUDE;decimal degree;-90;90;%+8.4lf;99.9999
LATD;LATITUDE DEGREES;degree;-90;90;%+3.0lf;99
LATM;LATITUDE MINUTES;minute;0;59.999;%6.3lf;99.999
LTUW;LEUCINE UPTAKE RATE;microgram carbon/(m3.h);0;90;%5.2lf;99.99
TUR2;LIGHT ATTENUATION COEFFICIENT;m-1;0;10;%6.3lf;99.999
LCAW;LIGHT CARBON ABSORPTION;milligram/m3;0;40;%5.2lf;99.99
TUR1;LIGHT DIFFUSION COEFFICIENT;m-1;0;10;%6.3lf;99.999
LGH3;LIGHT IRRADIANCE CORRECTED PAR;micromole photon/(m2.s);0;3000;%8.3lf;9999.999;0 500|0 1000|0 2000
LGHT;LIGHT IRRADIANCE IMMERGED PAR;micromole photon/(m2.s);0;4000;%8.3lf;9999.999;;0 500|0 1000|0 2000
LGH4;LIGHT IRRADIANCE SURFACE PAR;micromole photon/(m2.s);0;3000;%8.3lf;9999.999;;0 500|0 1000|0 2000
LSCT;LIGHT SCATTERING;%;0;100;%5.2lf;99.99;0 10|0 50|0 75|25 50|25 75|25 100|50 75|50 100|75 100
TUR3;LIGHT TRANSMISSION;%;0;100;%6.2lf;999.99;0 10|0 50|0 75|25 50|25 75|25 100|50 75|50 100|75 100
TUR0;LIGHT TRANSMISSION -  NOT USED;%;0;100;%6.2lf;999.99;0 10|0 50|0 75|25 50|25 75|25 100|50 75|50 100|75 100
LIPI;LIPIDS IN THE WATER COLUMN;milligram/m3;0;200;%5.0lf;99999
LSIC;LITHOGENIC CONTENT;%;0;99.99;%5.2lf;99.99
LTHF;LITHOGENIC FRACTION FLUX;milligram/(m2.day);0;3400;%7.2lf;9999.99
LINC;LONG-WAVE INCOMING RADIATION;watt/m2;-500;500;%+5.1lf;-999.9
LONX;LONGITUDE;decimal degree;-180;180;%+9.4lf;999.9999
LOND;LONGITUDE DEGREES;degree;-179;180;%+4.0lf;999
LONM;LONGITUDE MINUTES;minute;0;59.999;%6.3lf;99.999
MLAS;La IN THE SEDIMENT;ppm;0;900;%6.2lf;999.99
VZMX;MAXI ZERO CROSSING WAVE HEIGHT;metre;0;10;%5.2lf;99.99
MSMP;MEAN SPHERIC DIAM. MEDIAN;millimeter;0;99;%5.2lf;99.99
MSDP;MEAN SPHERIC DIAM. OF PARTICLE;millimeter;0;99;%5.2lf;99.99
MSZW;MESOZOOPLANCTON DRY WEIGHT;milligram/m3;0;90;%5.2lf;99.99
MMNF;MN FLUX IN SETTLING PARTICLES;microgram/(m2.day);0;3400;%6.2lf;999.99
SSTM;MODEL SEA SURFACE TEMPERATURE;Celsius degree;-1.5;38;%6.3lf;99.999
MNTH;MONTH;mm;1;12;%2.2d;99
MMGP;Mg IN SUSPENDED MATTER;milligram/m3;0;99.999;%6.3lf;99.999
MMGS;Mg IN THE SEDIMENT;%;0;99;%6.3lf;99.999
MMNP;Mn IN SUSPENDED MATTER;milligram/m3;0;99.999;%6.3lf;99.999
MMNS;Mn IN THE SEDIMENT;%;0;99;%6.3lf;99.999
MMOS;Mo IN THE SEDIMENT;ppm;0;900;%6.2lf;999.99
HBAW;NB OF HETEROTROPHIC BACTERIA;10+6 cell/m3;0;900000;%6.0lf;999999
NETR;NET RADIATION;watt/m2;-500;500;%+5.1lf;-999.9
NTRA;NITRATE (NO3-N) CONTENT;millimole/m3;0;56;%6.3lf;99.999;0 1|0 5|0 10|0 20
NTAW;NITRATE (NO3-N) CONTENT;micromole/kg;0;90;%5.2lf;99.99;0 1|0 5|0 10|0 20|0 50
NTRZ;NITRATE + NITRITE CONTENT;millimole/m3;0;100;%6.2lf;999.99
NTZW;NITRATE + NITRITE CONTENT;micromole/kg;0;100;%6.2lf;999.99
NOUW;NITRATE UPTAKE;micromole nitrogen/(m3.day);0;900;%5.0lf;99999
NORW;NITRIFICATION;micromole nitrogen/(m3.day);0;100;%5.0lf;99999
NTIW;NITRITE (NO2-N) CONTENT;micromole/kg;0;100;%7.3lf;999.999;0 1|0 2|0 5|0 10|0 20|0 50
NTRI;NITRITE (NO2-N) CONTENT;millimole/m3;0;10;%6.3lf;99.999;0 1|0 2|0 5
PHCW;NUM. OF SW PHYTOPLANKTON CELLS;10+3 cell/m3;0;900000;%6.0lf;999999
COPP;NUMBER OF COPEPODS;number/m3;0;99999;%5.0lf;99999
NUMP;NUMBER OF PARTICLES;number/m3;0;999999;%9.3e;1.00E+100
BCCW;NUMBER OF SW BACTERIA;10+9 cell/m3;0;9000;%7.2lf;9999.99
CICW;NUMBER OF SW CILIATES;10+3 cell/m3;0;90000;%5.0lf;99999
COCW;NUMBER OF SW COCCOLITHOPHORIDS;10+3 cell/m3;0;900000;%6.0lf;999999
DTCW;NUMBER OF SW DIATOMS;10+3 cell/m3;0;900000;%6.0lf;999999
DFCW;NUMBER OF SW DINOFLAGELLATES;10+3 cell/m3;0;900000;%6.0lf;999999
NFCW;NUMBER OF SW NANOFLAGELLATES;10+3 cell/m3;0;900000;%6.0lf;999999
PCEW;NUMBER OF SW PICOEUCARYOTES;10+6 cell/m3;0;90000;%5.0lf;99999
PRCW;NUMBER OF SW PROCHLOROCOCCUS;10+6 cell/m3;0;900000;%6.0lf;999999
SNCW;NUMBER OF SW SYNECHOCOCCUS;10+6 cell/m3;0;900000;%6.0lf;999999
MNAS;Na IN THE SEDIMENT;%;0;99;%6.3lf;99.999
MNBS;Nb IN THE SEDIMENT;ppm;0;900;%6.2lf;999.99
MNDS;Nd IN THE SEDIMENT;ppm;0;900;%6.2lf;999.99
MNIS;Ni IN THE SEDIMENT;ppm;0;900;%6.2lf;999.99
SLEV;OBSERVED SEA LEVEL;meter;0;6000;%8.3lf;9999.999
OPAP;OPAL CONTENT;%;0;99.99;%5.2lf;99.99
TOMP;ORGANIC MATTER CONTENT;%;0;99.99;%5.2lf;99.99
OSMP;ORGANIC SUSPENDED MATTER;gram/m3;0;10;%6.3lf;99.999
OSAT;OXYGEN SATURATION;%;0;10;%5.2lf;99.99
MPPP;P IN SUSPENDED MATTER;milligram/m3;0;99.999;%6.3lf;99.999
MPPS;P IN THE SEDIMENT;%;0;99;%6.3lf;99.999
SIOF;PART. BIOGENIC Si FLUX;milligram/(m2.day);0;600;%7.3lf;999.999
CO3F;PART. CaCO3 FLUX;milligram/(m2.day);0;600;%7.3lf;999.999
POCF;PART. ORGANIC CARBON FLUX;milligram/(m2.day);0;99;%5.2lf;99.99
OMMF;PART. ORGANIC MATTER FLUX;milligram/(m2.day);0;600;%6.2lf;999.99
PP1P;PART. ORGANIC PHOSPHORUS (P);millimole/m3;0;10;%6.3lf;99.999
CHTF;PART. TOTAL CARBOHYDRATES FLUX;milligram/(m2.day);0;99;%6.3lf;99.999
TCCF;PART. TOTAL CARBON FLUX;milligram/(m2.day);0;999;%7.3lf;999.999
TNNF;PART. TOTAL NITROGEN FLUX;milligram/(m2.day);0;99;%6.3lf;99.999
ETHP;PARTICULATE 234 TH ACT. ERROR;Bq/m3;0;99;%6.3lf;99.999
TH4P;PARTICULATE 234TH ACTIVTY;Bq/m3;0;99;%6.3lf;99.999
PC1P;PARTICULATE ORGANIC CARBON/POC;millimole/m3;0;100;%6.3lf;99.999
POCP;PARTICULATE ORGANIC CARBON/POC;milligram/m3;0;999;%6.2lf;999.99
PN1P;PARTICULATE ORGANIC NITROGEN;millimole/m3;0;2;%6.3lf;99.999
PONP;PARTICULATE ORGANIC NITROGEN;milligram/m3;0;100;%6.2lf;999.99
SLCP;PARTICULATE ORGANIC SILICA(SI);millimole/m3;0;1;%6.3lf;99.999
MPBF;PB FLUX IN SETTLING PARTICLES;microgram/(m2.day);0;200;%6.2lf;999.99
PERP;PERIDININE;milligram/m3;0;5;%6.3lf;99.999
PHPH;PH;pH unit;7.4;8.4;%5.3lf;9.999
PHTF;PHAEOPIGMENTS VERTICAL FLUX;milligram/(m2.day);0;10;%6.3lf;99.999
PHEA;PHEOPHYTIN-A;milligram/m3;0;99;%5.2lf;99.99
PHEB;PHEOPHYTIN-B;milligram/m3;0;99;%5.2lf;99.99
PHEC;PHEOPHYTIN-C;milligram/m3;0;99;%5.2lf;99.99
PHOS;PHOSPHATE (PO4-P) CONTENT;millimole/m3;0;4;%6.3lf;99.999;0 1|0 2
PHOW;PHOSPHATE (PO4-P) CONTENT;micromole/kg;0;10;%5.3lf;9.999;0 1|0 2|0 5
HEAD;PLATFORM HEADING REL. NORTH;degree;-360;360;%+5.1lf;-999.9
PSAL;PRACTICAL SALINITY;P.S.U.;33;37;%6.3lf;99.999;33.5 37.5|30 36|30 37|32 36|33 36|33 37|34 36|34 37|34 37.5|30 40
PXAP;PRASINOXANTHINE;milligram/m3;0;5;%6.3lf;99.999
PRRT;PRECIPITATION RATE;millimeter/hour;0;900;%7.3lf;999.999
PROT;PROTEIN;milligram/m3;0;500;%5.0lf;99999
PTZF;PROTOZOA PPC FLUX;milligram C/(m2.day);0;99.999;%6.3lf;99.999
MPBS;Pb IN THE SEDIMENT;ppm;0;900;%6.2lf;999.99
REDS;REDOX POTENTIAL;millivolt;-110;200;%+4.0lf;-999
RELH;RELATIVE HUMIDITY;%;0;100;%5.1lf;999.9
MRBS;Rb IN THE SEDIMENT;ppm;0;900;%6.2lf;999.99
MSSP;S IN SUSPENDED MATTER;milligram/m3;0;99.999;%6.3lf;99.999
SSAL;SALINITY (PRE-1978 DEFN);P.S.U.;0;40;%6.3lf;99.999
SACC;SALINITY ACCURACY;.;0;4;%2d;-9
SAND;SAND IN THE SEDIMENT;%;0;100;%6.2lf;999.99
PRES;SEA PRESSURE sea surface=0;decibar=10000 pascals;0;6500;%6.1lf;-999.9;0 50|0 100|0 250|0 500|0 700|0 800|0 900|0 1000|0 1200|0 1500|0 2000|0 2500|0 4000|1000 2000|2000 4000
SCDT;SEA SURF CURRENT DIR. REL T. N;degree;0;360;%5.1lf;999.9
SCSP;SEA SURFACE CURRENT SPEED;meter/second;0;10;%5.2lf;99.99
SSPS;SEA SURFACE PRACTICAL SALINITY;P.S.U.;0;40;%6.3lf;99.999;30 36|30 37|32 37;33 37|34 35|34 36|33.5 37.5
SSTP;SEA SURFACE TEMPERATURE;Celsius degree;-1.5;38;%6.3lf;99.999;0 10|0 20|0 30|10 20|10 30|20 30|20 32|26 32|20 40
TEMP;SEA TEMPERATURE;Celsius degree;0;30;%6.3lf;99.999;0 10|0 20|0 30|0 32|10 20|10 30|10 32|20 30|20 32|20 40
TE03;SEA TEMPERATURE;Celsius degree;-2;32;%6.3lf;99.999;0 30|10 30|20 30|15 25
TE04;SEA TEMPERATURE;Celsius degree;-2;32;%6.3lf;99.999;0 30|10 30|20 30|15 25
TE05;SEA TEMPERATURE;Celcius degree;-2;32;%6.3lf;99.999;0 30|10 30|20 30|15 25
TE07;SEA TEMPERATURE;Celsius degree;-2;32;%6.3lf;99.999;0 30|10 30|20 30|15 25
TE12;SEA TEMPERATURE;Celsius degree;-2;32;%6.3lf;99.999;0 30|10 30|20 30|15 25
TE11;SEA TEMPERATURE;Celsius degree;-2;32;%6.3lf;99.999;0 30|10 30|20 30|15 25
TE10;SEA TEMPERATURE;Celsius degree;-2;32;%6.3lf;99.999;0 30|10 30|20 30|15 25
TE09;SEA TEMPERATURE;Celsius degree;-2;32;%6.3lf;99.999;0 30|10 30|20 30|15 25
TE08;SEA TEMPERATURE;Celsius degree;-2;32;%6.3lf;99.999;0 30|10 30|20 30|15 25
TE06;SEA TEMPERATURE;Celsius degree;-2;32;%6.3lf;99.999;0 30|10 30|20 30|15 25
TE06;SEA TEMPERATURE;Celsius degree;-2;32;%6.3lf;99.999
SECS;SECONDS WITHIN MINUTE;ss;0;59;%2.2d;99
AMIS;SEDIMENT AMINO-ACIDS;microgram/g;0;7000;%4.0lf;9999
SIOS;SEDIMENT BIOGENIC SiO2;%;0;100;%6.2lf;999.99
CHTS;SEDIMENT CARBOHYDRATES;microgram/g;0;7000;%4.0lf;9999
CO3S;SEDIMENT CARBONATES;%;0;100;%6.2lf;999.99
LIPS;SEDIMENT LIPIDS;microgram/g;0;5000;%4.0lf;9999
PHNS;SEDIMENT PHENOLS;microgram/g;0;200;%5.1lf;999.9
TCCS;SEDIMENT TOTAL CARBON;%;0;100;%6.2lf;999.99
TNNS;SEDIMENT TOTAL NITROGEN;%;0;100;%6.2lf;999.99
TOCS;SEDIMENT TOTAL ORGANIC CARBON;%;0;100;%6.2lf;999.99
VTDH;SIGNIFICANT WAVE HEIGHT;meter;0;99.999;%6.3lf;99.999
SLCA;SILICATE (SIO4-SI) CONTENT;millimole/m3;0;200;%7.3lf;999.999
SLCW;SILICATE (SIO4-SI) CONTENT;micromole/kg;0;195;%5.1lf;999.9;0 10|0 20|0 30|0 40|0 50|0 100
SILT;SILT IN THE SEDIMENT;%;0;100;%6.2lf;999.99
SVEL;SOUND VELOCITY;meter/second;1350;1600;%7.2lf;9999.99
SWDR;SWELL DIRECTION  REL TRUE N.;degree;0;360;%5.1lf;999.9
SWHT;SWELL HEIGHT;meter;0;30;%5.2lf;99.99
MSCS;Sc IN THE SEDIMENT;ppm;0;900;%6.2lf;999.99
MSIP;Si IN SUSPENDED MATTER;milligram/m3;0;999.999;%7.3lf;999.999
MSIS;Si IN THE SEDIMENT;%;0;99;%6.3lf;99.999
MSRS;Sr IN THE SEDIMENT;ppm;0;900;%6.2lf;999.99
TACC;TEMPERATURE ACCURACY;.;0;4;%2d;-9
TIME;TIME WITHIN DAY;hhmmss;0;235959;%6.6d;999999
TCO2;TOTAL CARBON DIOXYD (CO2);mole/m3;0;5000;%8.3lf;9999.999
TDCW;TOTAL DISSOLVED CARBON;millimole/m3;0;9999;%4.0lf;9999
TDPW;TOTAL DISSOLVED PHOSPHORUS;millimole/m3;0;40;%6.3lf;99.999
TICW;TOTAL INORGANIC CARBON;micromole/kg;0;9000;%7.2lf;9999.99
TSMF;TOTAL MASS FLUX;milligram/(m2.day);0;9999.9;%6.1lf;9999.9
NTOT;TOTAL NITROGEN (N) CONTENT;millimole/m3;0;90;%5.2lf;99.99
TOCW;TOTAL ORGANIC CARBON;millimole/m3;0;999.999;%7.3lf;999.999
NOTT;TOTAL ORGANIC NITROGEN (D+P);micromole/kg;0;10;%5.2lf;99.99
POTT;TOTAL ORGANIC PHOSPHORUS (D+P);micromole/kg;0;5;%5.2lf;99.99
PTNP;TOTAL PARTICULATE NITROGEN;milligram/m3;0;5;%5.2lf;99.99
NT1P;TOTAL PARTICULATE NITROGEN;micromole/kg;0;10;%5.2lf;99.99
PTPP;TOTAL PARTICULATE PHOSPHORUS;milligram/m3;0;5;%5.2lf;99.99
PT1P;TOTAL PARTICULATE PHOSPHORUS;micromole/kg;0;5;%5.2lf;99.99
TPHP;TOTAL PHAEOPIGMENTS;milligram/m3;0;100;%6.3lf;99.999
PHTP;TOTAL PHEOPHYTINE;milligram/m3;0;99;%5.2lf;99.99
TPHS;TOTAL PHOSPHORUS (P) CONTENT;millimole/m3;0;10;%5.2lf;99.99
EPMP;TOTAL SUSP. PART. MATTER/ESTER;gram/m3;0;9;%5.3lf;9.999
GPMP;TOTAL SUSP. PART. MATTER/GLASS;gram/m3;0;99;%6.3lf;99.999
TSMP;TOTAL SUSPENDED MATTER;gram/m3;0;100;%7.3lf;999.999
TUR4;TURBIDITY;N.T.U Nephelo Turb. Unit;0;100;%6.2lf;999.99
TUR5;TURBIDITY;relative unit;0;10;%7.4lf;99.9999
TUR6;TURBIDITY;milliF.T.U Formaz Turb Unit;0;5000;%6.1lf;9999.9
MTHS;Th IN THE SEDIMENT;ppm;0;900;%6.2lf;999.99
MTIP;Ti IN SUSPENDED MATTER;milligram/m3;0;99.999;%6.3lf;99.999
MTIS;Ti IN THE SEDIMENT;%;0;99;%6.3lf;99.999
MUUS;U IN THE SEDIMENT;ppm;0;900;%6.2lf;999.99
UREA;UREA;millimole/m3;0;5;%5.2lf;99.99
MVVS;V IN THE SEDIMENT;ppm;-50;900;%+6.2lf;99.99
VERR;VELOCITY ERROR;meter/second;0;90;%6.3lf;99.999
VCSP;VERTICAL CURRENT SPEED;meter/second;0;9;%5.3lf;9.999
VERT;VERTICAL DISPLACEMENT;meter;0;9999;%8.3lf;9999.999
VOCP;VOLUME CONC. OF PARTICLES;p.p.m.;0;99;%6.3lf;99.999
H2OS;WATER CONTENT;%;0;100;%5.1lf;999.9
WDIR;WIND DIRECTION REL. TRUE NORTH;degree;0;360;%+5.1lf;-999.9
WMSP;WIND SPEED - MAX AVER PER 2 MN;meter/second;0;200;%5.2lf;99.99
WSPE;WIND SPEED EASTWARD COMPONENT;meter/second;0;100;%7.3lf;999.999
WSPN;WIND SPEED NORTHWARD COMPONENT;meter/second;0;100;%7.3lf;999.999
MYYS;Y IN THE SEDIMENT;ppm;0;900;%6.2lf;999.99
YEAR;YEAR;yyyy;1900;2020;%4.4d;9999
ZXAP;ZEAXANTHINE;milligram/m3;0;5;%6.3lf;99.999
MZNF;ZN FLUX IN SETTLING PARTICLES;microgram/(m2.day);0;7600;%6.2lf;999.99
MZNS;Zn IN THE SEDIMENT;ppm;0;900;%6.2lf;999.99
MZRS;Zr IN THE SEDIMENT;ppm;0;900;%6.2lf;999.99
SSJT;SEA SURFACE WATER JACKET TEMPERATURE;Celsius degree;-1.5;38;%6.3lf;99.999;0 10|0 20|0 30|10 20|10 30|20 30|20 32|26 32|20 40
DAYD;DECIMAL JULIAN DAY;decimal day;0.0;3660.0;%9.5lf;999.99999
TE01;SEA TEMPERATURE PRIMARY SENSOR;Celsius degree;-2;32;%6.3lf;99.999;0 10|0 20|0 30|0 32|10 20|10 30|10 32|20 30|20 32|20 40
TE02;SEA TEMPERATURE SECONDARY SENSOR;Celsius degree;-2;32;%6.3lf;99.999;0 10|0 20|0 30|0 32|10 20|10 30|10 32|20 30|20 32|20 40
PSA1;PRACTICAL SALINITY PRIMARY SENSOR;P.S.U.;33;37;%6.3lf;99.999;33.5 37.5|30 36|30 37|32 36|33 36|33 37|34 36|34 37|34 37.5|30 40
PSA2;PRACTICAL SALINITY SECONDARY SENSOR;P.S.U.;33;37;%6.3lf;99.999;33.5 37.5|30 36|30 37|32 36|33 36|33 37|34 36|34 37|34 37.5|30 40
CND1;ELECTRICAL CONDUCTIVITY PRIMARY SENSOR;mho/meter;3;7;%5.3lf;9.999
CND2;ELECTRICAL CONDUCTIVITY SECONDARY SENSOR;mho/meter;3;7;%5.3lf;9.999
DO11;DISSOLVED OXYGEN PRIMARY SENSOR;ml/l;0;10;%5.2lf;99.99;0 4|0 6|2 6|0 8|2 8
DO21;DISSOLVED OXYGEN SECONDARY SENSOR;ml/l;0;10;%5.2lf;99.99;0 4|0 6|2 6|0 8|2 8
DO12;DISSOLVED OXYGEN PRIMARY SENSOR;micromole/kg;0;450;%7.3lf;999.999;0 100|0 200|100 300
DO22;DISSOLVED OXYGEN SECONDARY SENSOR;micromole/kg;0;450;%7.3lf;999.999;0 100|0 200|100 300
WETT;WET BULB TEMPERATURE;Celsius degree;0;90;%5.1lf;999.9
HEIG;ATMOSPHERIC HEIGHT;meter;0;40000;%8.2lf;1e+36;0 100|0 500|0 1000|0 5000|0 10000|0 20000|0 30000
WVDA;MASSE OF WATER VAPOR/MASSE OF DRY AIR RATIO;%;0;100;%6.2lf;999.99;0 10|0 50|0 75|25 50|25 75|25 100|50 75|50 100|75 100
