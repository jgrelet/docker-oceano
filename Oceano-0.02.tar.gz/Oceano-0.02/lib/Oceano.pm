# Module principal de la distribution Oceano
# La distribution porte le numero de version de ce module
#
# $Id: Oceano.pm 273 2007-04-23 08:56:06Z nrannou $

package Oceano;

use warnings;
use strict;

=head1 NAME

Oceano - Perl extensions to manipulate oceanographic data

=head1 VERSION

Version 0.02

=cut

our $VERSION = '0.02';

=head1 SYNOPSIS

This distribution contains tools to convert dates, calculate oceanographic
parametres... 

Modules
    Oceano::Convert - Perl extension to convert dates or positions
    Oceano::Seawater - Perl extension to compute oceanographic parameters

=head1 AUTHOR

Jacques Grelet, C<< <jacques.grelet at ird.fr> >>

Nolwenn Rannou

=head1 SUPPORT

You can find documentation for this module with the perldoc command.

    perldoc Oceano
    perldoc Oceano::Convert
    perldoc Oceano::Seawater

You can also look for information at:

=head1 ACKNOWLEDGEMENTS

=head1 COPYRIGHT & LICENSE

Copyright 2007 Jacques Grelet, all rights reserved.

This program is free software; you can redistribute it and/or modify it
under the same terms as Perl itself.

=cut

1;    # End of Oceano
